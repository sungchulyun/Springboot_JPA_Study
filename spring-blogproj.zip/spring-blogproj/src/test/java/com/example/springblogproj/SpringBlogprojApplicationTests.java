package com.example.springblogproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBlogprojApplicationTests {

	@Test
	void contextLoads() {
	}

}
