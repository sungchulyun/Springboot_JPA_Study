package com.example.springblogproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBlogprojApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBlogprojApplication.class, args);
	}

}
